% This demo shows the reconstruction of a sparse image
% of randomly placed plus an minus ones
% HTTCGP 
clear all
close all
clf
randn('seed',1); % 1 for the experiments in the paper
rand('seed',1); % 1 for the experiments in the paper
addpath Images
% the test images set
A={ 'lena.bmp' 'boat.bmp' 'bridge.bmp' 'flower.bmp' 'rose.bmp' ...
    'peppers.bmp' 'cameraman2.bmp' 'fruits.bmp' 'man.bmp' 'shape.jpg' 'hill.png' 'baboon.bmp'};
% f = double(imread('cameraman.png'));
% f = double(imread('lena.png'));
% f = double(imread('barbara.png'));
% f = double(imread('man.bmp'));
%for i = 1:4
f=double(imread(A{4})); %{2}
[m,n] = size(f);
scrsz = get(0,'ScreenSize');
figure(1)
%set(1,'Position',[10 scrsz(4)*0.05 scrsz(3)/4 0.85*scrsz(4)])
% subplot(1,2,1)
imagesc(f)
colormap(gray(255))
axis off
axis equal
title('Original image','FontName','Times','FontSize',22)
% title(sprintf('Original: %4d  %4d',m,n),'FontSize',22)
% create observation operator; in this case 
% it will be a blur function composed with an
% inverse weavelet transform
disp('Creating observation operator...');

middle = n/2 + 1;

% uncomment the following lines for Experiment 1 (see paper)
% sigma = 0.56;
% h = zeros(size(f));
% for i=-4:4
%    for j=-4:4
%       h(i+middle,j+middle)= 1; 
%    end
% end


% uncomment the following lines for Experiment 2 (see paper)
% sigma = sqrt(2);
sigma = sqrt(0.01);
h = zeros(size(f)); % h is the same size as f and all zeros.
for i=-4:4
   for j=-4:4
      h(i+middle,j+middle)= (1/(1+i*i+j*j));
   end
end

% uncomment the following lines for Experiment 3 (see paper)
% sigma = sqrt(8);
% h = zeros(size(f));
% for i=-4:4
%    for j=-4:4
%       h(i+middle,j+middle)= (1/(1+i*i+j*j));
%    end
% end

% % center and normalize the blur
h = fftshift(h);  % ��Ƶ��ͼ��λ����Ƶ����Ƶ��ͼ����
% fftshift is useful for visualizing the Fourier transform with the zero-frequency component in the middle of the spectrum.
h = h/sum(h(:));  % sum(h(:)): sum all elements of h.

% definde the function handles that compute 
% the blur and the conjugate blur.
R = @(x) real(ifft2(fft2(h).*fft2(x))); % fft2(X) returns the two-dimensional Fourier transform of matrix X.
% ifft2(F) returns the two-dimensional inverse Fourier transform of matrix F
RT = @(x) real(ifft2(conj(fft2(h)).*fft2(x)));


% define the function handles that compute 
% the products by W (inverse DWT) and W' (DWT)
wav = daubcqf(2);
W = @(x) midwt(x,wav,3);
WT = @(x) mdwt(x,wav,3);

%Finally define the function handles that compute 
% the products by A = RW  and A' =W'*R' 
A = @(x) R(W(x));
AT = @(x) WT(RT(x));

fid=fopen('mytext.txt','w');
% generate noisy blurred observations
y = R(f) + sigma*randn(size(f));
figure(2)
% subplot(1,2,2)
imagesc(y)
colormap(gray(255))
axis off
axis equal
title('Blurred image','FontName','Times','FontSize',22)
% title(['Blurred: ',num2str(blur_label),'dB'],'FontName','Times','FontSize',22)

% regularization parameterMITTCGP
tau = .35;

% set tolA
tolA = 1.e-5;
% Run PDY until the relative change in objective function is no
% larger than tolA

%jzy
disp('Starting jzy_CS_image ...')
[x_jzyCS,theta_debias,obj_jzyCS,t_jzyCS,debias_jzyCS,mses_jzyCS]= ...
	jzy_CS(y,A,tau,...
	'Debias',0,...
	'AT',AT,... 
    'True_x',WT(f),...
	'Initialization',AT(y),... %0,...%
	'StopCriterion',1,...
	'ToleranceA',tolA,...
     'Verbose',0);
 SNR_jzyCS=20*log10(norm(f,'fro')/norm(f-W(x_jzyCS),'fro'));
 Itr_jzyCS = length(t_jzyCS);
 fprintf(1,'jzyCS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', Itr_jzyCS,...
      obj_jzyCS(end),t_jzyCS(end),mses_jzyCS(end)/m/n,SNR_jzyCS);



% Run HTTCGP  until the relative change in objective function is no
% larger than tolA
disp('Starting HTTCGP_CS_image ...')
[x_HTTCGPCS,theta_debias,obj_HTTCGPCS,t_HTTCGPCS,debias_HTTCGPCS,mses_HTTCGPCS]= ...
	HTTCGP_CS(y,A,tau,...
	'Debias',0,...
	'AT',AT,... 
    'True_x',WT(f),...
	'Initialization',AT(y),... %0,...%
	'StopCriterion',1,...
	'ToleranceA',tolA,...
     'Verbose',0);
 SNR_HTTCGPCS = 20*log10(norm(f,'fro')/norm(f-W(x_HTTCGPCS),'fro'));
 Itr_HTTCGPCS = length(t_HTTCGPCS);
 fprintf(1,'HTTCGPCS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', Itr_HTTCGPCS,...
      obj_HTTCGPCS(end),t_HTTCGPCS(end),mses_HTTCGPCS(end)/m/n,SNR_HTTCGPCS);
%  HTTCGP _label=[roundn(t_HTTCGP CS(end)) roundn(20*log10(norm(f,'fro')/norm(f-W(x_HTTCGP CS),'fro')))];
  % Run HTTCGP  until the relative change in objective function is no
% larger than tolA

% Run jzy until the relative change in objective function is no
% larger than tolA
disp('Starting PDY_CS_image ...')
[x_PDYCS,theta_debias,obj_PDYCS,t_PDYCS,debias_PDYCS,mses_PDYCS]= ...
	PDY_CS(y,A,tau,...
	'Debias',0,...
	'AT',AT,... 
    'True_x',WT(f),...
	'Initialization',AT(y),... %0,...%
	'StopCriterion',1,...
	'ToleranceA',tolA,...
     'Verbose',0);
 SNR_PDYCS = 20*log10(norm(f,'fro')/norm(f-W(x_PDYCS),'fro'));
 Itr_PDYCS = length(t_PDYCS);
 fprintf(1,'PDYCS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', Itr_PDYCS,...
      obj_PDYCS(end),t_PDYCS(end),mses_PDYCS(end)/m/n,SNR_PDYCS);
%   PDY_label=[roundn(t_PDYCS(end)) roundn(20*log10(norm(f,'fro')/norm(f-W(x_PDYCS),'fro')))];
  

%   PDY_label=[roundn(t_PDYCS(end)) roundn(20*log10(norm(f,'fro')/norm(f-W(x_PDYCS),'fro')))];
  

%  PDY_label=[roundn(t_PDYCS(end)) roundn(20*log10(norm(f,'fro')/norm(f-W(x_PDYCS),'fro')))];


% disp('Starting NDYSPCGP_CS_image ...')
% [x_NDYSPCGPCS,theta_debias,obj_NDYSPCGPCS,t_NDYSPCGPCS,debias_NDYSPCGPCS,mses_NDYSPCGPCS]= ...
% 	NDYSPCGP_CS(y,A,tau,...
% 	'Debias',0,...
% 	'AT',AT,... 
%     'True_x',WT(f),...
% 	'Initialization',AT(y),... %0,...%
% 	'StopCriterion',1,...
% 	'ToleranceA',tolA,...
%      'Verbose',0);
%  SNR_NDYSPCGPCS=20*log10(norm(f,'fro')/norm(f-W(x_NDYSPCGPCS),'fro'));
%  Itr_NDYSPCGPCS = length(t_NDYSPCGPCS);
%  fprintf(1,'NDYSPCGPCS: Iter=%4d, obj=%10.3e, times=%6.2f, MSE=%10.4e, SNR=%6.2f\n', Itr_NDYSPCGPCS,...
%       obj_NDYSPCGPCS(end),t_NDYSPCGPCS(end),mses_NDYSPCGPCS(end)/m/n,SNR_NDYSPCGPCS);

%psnr_HTTCGP CS = mpsnr(f,W(x_HTTCGP CS));
psnr_HTTCGPCS = mpsnr(f,W(x_HTTCGPCS));
psnr_PDYCS = mpsnr(f,W(x_PDYCS));

psnr_jzyCS = mpsnr(f,W(x_jzyCS));
%psnr_NDYSPCGPCS = mpsnr(f,W(x_NDYSPCGPCS));
%mssim_HTTCGP CS = ssim(f, W(x_HTTCGP CS));       % [mssim, ssim_map] = ssim(f, g);
mssim_HTTCGPCS = ssim(f, W(x_HTTCGPCS));
mssim_PDYCS = ssim(f, W(x_PDYCS));
mssim_jzyCS = ssim(f, W(x_jzyCS));
%mssim_NDYSPCGPCS = ssim(f, W(x_NDYSPCGPCS));

fprintf(fid,'%d/%.2f/%.2f/%.2f & %d/%.2f/%.2f/%.2f & %d/%.2f/%.2f/%.2f\\\\\n', ... 
        Itr_jzyCS,t_jzyCS(end),psnr_jzyCS,mssim_jzyCS,Itr_HTTCGPCS,t_HTTCGPCS(end),psnr_HTTCGPCS,mssim_HTTCGPCS,Itr_PDYCS,t_PDYCS(end),psnr_PDYCS,mssim_PDYCS);
fclose(fid);
  
% %% ================= Plotting results ==========
figure(3)
% subplot(1,5,3)
% if prod(size(theta_debias))~=0 % prod(size(theta_debias)) is the product of the elements of the vector (size(theta_debias)
%    imagesc(W(theta_debias))
% else
   imagesc(W(x_HTTCGPCS))
% end
colormap(gray)
axis off
axis equal
title('HTTCGP ','FontName','Times','FontSize',22)

figure(4)
% subplot(1,5,4)
imagesc(W(x_PDYCS))
colormap(gray)
axis off
axis equal
title('PDY','FontName','Times','FontSize',22)

% 
figure(5)
% subplot(1,5,5)
imagesc(W(x_jzyCS))
colormap(gray)
axis off
axis equal
title('F-CGPM','FontName','Times','FontSize',22)


% figure(6)
% imagesc(W(x_NDYSPCGPCS))
% colormap(gray)
% axis off
% axis equal
% title('NDYSPCGP','FontName','Times','FontSize',22)
% 
% figure(11)
% scrsz = get(0,'ScreenSize');
% lft = 0.55*scrsz(3)-10;
% btm = 0.525*scrsz(4);
% wdt = 0.45*scrsz(3);
% hgt = 0.375*scrsz(4);
% 
% set(2,'Position',[lft btm wdt hgt])
% plot(obj_QP_BB_mono,'b','LineWidth',1.8);
% hold on
% plot(obj_QP_BB_notmono,'r--','LineWidth',1.8);
% plot(obj_SGCS,'g:','LineWidth',1.8);
% plot(obj_IST,'m-.','LineWidth',1.8);
% hold off
% leg = legend('GPSR-BB monotone','GPSR-BB non-monotone','SGCS','IST');
% v = axis;
% if debias_start ~= 0
%    line([debias_start,debias_start],[v(3),v(4)],'LineStyle',':')
%    text(debias_start+0.01*(v(2)-v(1)),...
%    v(3)+0.8*(v(4)-v(3)),'Debiasing')
% end
% ylabel('Objective function','FontName','Times','FontSize',16)
% xlabel('Iterations','FontName','Times','FontSize',16)
% 
% 
% set(leg,'FontName','Times');
% set(leg,'FontSize',16);
% set(gca,'FontName','Times');
% set(gca,'FontSize',16);
%     
% 
% figure(12)
% scrsz = get(0,'ScreenSize');
% lft = 0.55*scrsz(3)-10;
% btm = 0.025*scrsz(4);
% wdt = 0.45*scrsz(3);
% hgt = 0.375*scrsz(4);
%  
% set(3,'Position',[lft btm wdt hgt])
% plot(times_QP_BB_mono,obj_QP_BB_mono,'b','LineWidth',1.8);
% hold on
% plot(times_QP_BB_notmono,obj_QP_BB_notmono,'r--','LineWidth',1.8);
% plot(t_SGCS,obj_SGCS,'g:','LineWidth',1.8);
% plot(times_IST,obj_IST,'m-.','LineWidth',1.8);
% hold off
% leg = legend('GPSR-BB monotone','GPSR-BB non-monotone','SGCS','IST');
% v = axis;
% if debias_start ~= 0
%    line([debias_start,debias_start],[v(3),v(4)],'LineStyle',':')
%    text(debias_start+0.01*(v(2)-v(1)),...
%    v(3)+0.8*(v(4)-v(3)),'Debiasing')
% end
% ylabel('Objective function','FontName','Times','FontSize',16)
% xlabel('CPU time (seconds)','FontName','Times','FontSize',16)
% 
% 
% set(leg,'FontName','Times');
% set(leg,'FontSize',16);
% set(gca,'FontName','Times');
% set(gca,'FontSize',16);
%     
% 
% figure(13)
% 
% plot(times_QP_BB_mono,mses_QP_BB_mono,'b','LineWidth',1.8);
% hold on
% plot(times_QP_BB_notmono,mses_QP_BB_notmono,'r--','LineWidth',1.8);
% plot(t_SGCS,mses_SGCS,'g:','LineWidth',1.8);
% plot(times_IST,mses_IST,'m-.','LineWidth',1.8);
% hold off
% leg = legend('GPSR-BB monotone','GPSR-BB non-monotone','SGCS','IST');
% v = axis;
% if debias_start ~= 0
%    line([debias_start,debias_start],[v(3),v(4)],'LineStyle',':')
%    text(debias_start+0.01*(v(2)-v(1)),...
%    v(3)+0.8*(v(4)-v(3)),'Debiasing')
% end
% ylabel('Deconvolution MSE','FontName','Times','FontSize',16)
% xlabel('CPU time (seconds)','FontName','Times','FontSize',16)
% 
% 
% set(leg,'FontName','Times');
% set(leg,'FontSize',16);
% set(gca,'FontName','Times');
% set(gca,'FontSize',16);

% fprintf(1,'\nSGCS monotone; cpu: %6.2f secs (%d iterations)\n',...
%         t_SGCS,length(t_SGCS))
% fprintf(1,'final value of the objective function = %6.3e, \nMSE of the solution = %6.3e\n',...
%           obj_SGCS(end),(1/(n*m))*norm(x_SGCS-f)^2)      



