 % This is a demo of HTTCGP_CS method for solving \ell_1-norm minimization
% problem
% arg min_x = 0.5*|| y - A x ||_2^2 + tau || x ||_1
% using the algorithm modified three-term conjugate gradient projection method, described in the following paper
%
% -----------------------------------------------------------------------
% Copyright (2019): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 29, 2019
clc
clear all
close all
%set parameters
randn('seed',1); % 1 for the experiments in the paper
rand('seed',1); % 1 for the experiments in the paper
% addpath('data') 
% parameter
steps = 5;
debias = 0;
stopCri=1;
tolA=1.e-5; % the stopping criterion 
fid=fopen('.\mytext6.txt','w');
for index=1:0.5:8
    % n is the original signal length
    n=1024*index;
    % k is number of observations to make
    k=256*index;
    % number of spikes to put down
    % n_spikes = floor(.01*n);
    n_spikes = 32*index;  % number of nonzeros
    % generate problems
    progress_r=[];
    for repeats=1:20
        % random +/- 1 signal
        f = zeros(n,1);
        q = randperm(n);
        % f(q(1:n_spikes)) = sign(randn(n_spikes,1));
        f(q(1:n_spikes)) = randn(n_spikes,1);
        disp('Creating measurement matrix...');
        R = randn(k,n);
%         for j=1:n
%             R(:,j) = R(:,j)/norm(R(:,j));%normalize R
%         end
        % orthonormalize rows  
        R = orth(R')'; 
%         if n==8192
%             load Rmatrix_2048_8192.mat
%         else
%             R = randn(k,n);
            % orthonormalize rows
%             R = orth(R')'; 
%         end
% %         if ~exist('R','var') % measurement matrix
% %             disp('Creating measurement matrix...');
% %             R = randn(k,n);
% %             % orthonormalize rows
% %             R = orth(R')';
% %         end
% %         if n == 8192  % in this case, we load a precomputed matrix to save some time
% %             load Rmatrix_2048_8192.mat
% %         end
        disp('Finished creating matrix');   
        %% Define all its functions:
        % Create handles to functions R(x)=Rx and R^{T}(x)=R^{T}x:
        hR = @(x) R*x;
        hRt = @(x) (x'*R)';% R'*x;
        % noisy observations
        sigma = 0.1;  % sigma = 0.0001;
        y = hR(f) + sigma*randn(k,1);
        % regularization parameter
        tau = 0.001*max(abs(R'*y));
        first_tau_factor = 0.9*(max(abs(R'*y))/tau);
      
        %% HTTCGP
        disp('Starting HTTCGP_CS monotonic with continuation')
        [x_HTTCGPCS_cont,x_debias_HTTCGPCS_cont,obj_HTTCGPCS_cont,...
        times_HTTCGPCS_cont,debias_start_HTTCGPCS,mse_HTTCGPCS_cont]= ...
        HTTCGP_CS(y,R,tau,...
         'Debias',debias,...
         'Continuation',1,...
         'ContinuationSteps',steps,...
         'FirstTauFactor',first_tau_factor,...
         'Monotone',1,...
         'Initialization',2,...
         'True_x',f,...
         'StopCriterion',stopCri,...
       	 'ToleranceA',tolA,...
         'Verbose',0);
        t_HTTCGPCS_cont = times_HTTCGPCS_cont(end);
         Itr_HTTCGPCS=length(times_HTTCGPCS_cont);
%         Obj_HTTCGPCS = obj_HTTCGPCS_cont(end);
        MSE_HTTCGPCS = (1/n)*norm(x_HTTCGPCS_cont-f)^2;
        %% ATTCGP
        disp('Starting ATTCGP_CS monotonic with continuation')
        [x_ATTCGPCS_cont,x_debias_ATTCGPCS_cont,obj_ATTCGPCS_cont,...
        times_ATTCGPCS_cont,debias_start_ATTCGPCS,mse_ATTCGPCS_cont]= ...
        ATTCGP_CS(y,R,tau,...
         'Debias',debias,...
         'Continuation',1,...
         'ContinuationSteps',steps,...
         'FirstTauFactor',first_tau_factor,...
         'Monotone',1,...
         'Initialization',2,...
         'True_x',f,...
         'StopCriterion',stopCri,...
       	 'ToleranceA',tolA,...
         'Verbose',0);
        t_ATTCGPCS_cont = times_ATTCGPCS_cont(end);
         Itr_ATTCGPCS=length(times_ATTCGPCS_cont);
%         Obj_ATTCGPCS = obj_ATTCGPCS_cont(end);
        MSE_ATTCGPCS = (1/n)*norm(x_ATTCGPCS_cont-f)^2;

          %% jzy 
        disp('Starting jzy  monotonic with continuation')
        [x_jzyCS_cont,x_debias_jzyCS_cont,obj_jzyCS_cont,...
        times_jzyCS_cont,debias_start_jzyCS,mse_jzyCS_cont]= ...
        jzy_CS(y,R,tau,...
                  'Debias',debias,...
                  'Continuation',1,...
                  'ContinuationSteps',steps,...
                  'FirstTauFactor',first_tau_factor,...
                  'Monotone',1,...
                  'Initialization',2,...
                  'True_x',f,...
                  'StopCriterion',stopCri,...
       	          'ToleranceA',tolA,...
                  'Verbose',0);
        t_jzyCS_cont = times_jzyCS_cont(end);
         Itr_jzyCS=length(times_jzyCS_cont);
%         Obj_CGDCS = obj_CGDCS_cont(end);
        MSE_jzyCS = (1/n)*norm(x_jzyCS_cont-f)^2;
         progress_r=[progress_r;Itr_HTTCGPCS t_HTTCGPCS_cont MSE_HTTCGPCS  Itr_ATTCGPCS t_ATTCGPCS_cont MSE_ATTCGPCS Itr_jzyCS t_jzyCS_cont MSE_jzyCS]; 


    end
    fprintf(fid,'%d & %d & %d & %g/%.2f/%.3e & %g/%.2f/%.3e & %g/%.2f/%.3e& \n', ... 
        k,n,n_spikes,mean(progress_r));
end
fclose(fid);

% %
% fprintf(1,'\n\n-------------------------------------------------\n')   
% fprintf(1,'-------------------------------------------------\n')   
% fprintf(1,'Problem: n = %g,  k = %g, number of spikes = %g\n',n,k,n_spikes)
% fprintf(1,'Parameters: sigma = %g, tau = %g, debiasing = %g\n',sigma,tau,debias)
% fprintf(1,'All algorithms initialized with zeros\n')
% fprintf(1,'-------------------------------------------------\n')
% 
% fprintf(1,'\nCGDESCENT_CS monotone continuation; cpu: %6.2f secs (%d iterations)\n',...
%         t_CGDCS_cont,length(obj_CGDCS_cont))
% fprintf(1,'final value of the objective function = %6.3e, \nMSE of the solution = %6.3e\n',...
%           obj_CGDCS_cont(end),(1/n)*norm(x_CGDCS_cont-f)^2)      
% 
% fprintf(1,'\nHTTCGP_CS monotone continuation; cpu: %6.2f secs (%d iterations)\n',...
%         t_SGCS_cont,length(obj_SGCS_cont))
% fprintf(1,'final value of the objective function = %6.3e, \nMSE of the solution = %6.3e\n',...
%           obj_SGCS_cont(end),(1/n)*norm(x_SGCS_cont-f)^2)      
% 
%       
% fprintf(1,'-------------------------------------------------\n')
% fprintf(1,'-------------------------------------------------\n')
% 
% % ================= Plotting results ==========obj_IST,times_IST,debias_s,mses_IST
% %%
% figure(1)
% plot(mse_SGCS_cont,'b:','LineWidth',2)
% hold on
% plot(mse_CGDCS_cont,'r-','LineWidth',2)
% hold on
% legend('HTTCGP-CS','CGD') % SG-CS
% set(gca,'FontName','Times','FontSize',16)
% xlabel('Iterations')
% ylabel('MSE')
% title(sprintf('n=%d, k=%d, tau=%g',n,k,tau))
% axis on
% grid on
% hold off
% 
% figure(2)
% plot(times_SGCS_cont,mse_SGCS_cont,'b:','LineWidth',2)
% hold on
% plot(times_CGDCS_cont,mse_CGDCS_cont,'r-','LineWidth',2)
% legend('HTTCGP-CS','CGD')
% set(gca,'FontName','Times','FontSize',16)
% xlabel('CPU time (seconds)')
% ylabel('MSE')
% title(sprintf('n=%d, k=%d, tau=%g',n,k,tau))
% axis on
% grid on
% hold off
% % %==========================================================================
% figure(3)
% plot(obj_SGCS_cont,'b:','LineWidth',2)
% hold on
% plot(obj_CGDCS_cont,'r-','LineWidth',2)
% legend('HTTCGP-CS','CGD')
% set(gca,'FontName','Times','FontSize',16)
% xlabel('Iterations')
% ylabel('ObjFun')
% title(sprintf('n=%d, k=%d, tau=%g',n,k,tau))
% axis on
% grid on
% hold off
% % 
% figure(4)
% plot(times_SGCS_cont,obj_SGCS_cont,'b:','LineWidth',2)
% hold on
% plot(times_CGDCS_cont,obj_CGDCS_cont,'r-','LineWidth',2)
% hold on
% legend('HTTCGP-CS','CGD')
% set(gca,'FontName','Times','FontSize',16)
% xlabel('CPU time (seconds)')
% ylabel('ObjFun')
% title(sprintf('n=%d, k=%d, tau=%g',n,k,tau))
% axis on
% grid on
% hold off
% %==========================================================================
% %%
% figure(5)

%%  Plot
scrsz = get(0,'ScreenSize');
% set(7,'Position',[10 scrsz(4)*0.1 0.9*scrsz(3)/2 3*scrsz(4)/4])
subplot(5,1,1)
plot(f,'LineWidth',1.1)
top = max(f(:));
bottom = min(f(:));
v = [0 n+1 bottom-0.05*(top-bottom)  top+0.05*((top-bottom))];
set(gca,'FontName','Times')
set(gca,'FontSize',14)
title(sprintf('Original (n = %g, number of nonzeros = %g)',n,n_spikes))
axis(v)

scrsz = get(0,'ScreenSize');
% set(7,'Position',[10 scrsz(4)*0.1 0.9*scrsz(3)/2 3*scrsz(4)/4])
subplot(5,1,2)
plot(y,'LineWidth',1.1)
top = max(y(:));
bottom = min(y(:));
v = [0 k+1 bottom-0.05*(top-bottom)  top+0.05*((top-bottom))];
set(gca,'FontName','Times')
set(gca,'FontSize',14)
title(sprintf('Measurement'))
axis(v)

scrsz = get(0,'ScreenSize');
% set(7,'Position',[10 scrsz(4)*0.1 0.9*scrsz(3)/2 3*scrsz(4)/4])
subplot(5,1,3)
plot(x_HTTCGPCS_cont(:),'LineWidth',1.1)
top = max(x_HTTCGPCS_cont(:));
bottom = min(x_HTTCGPCS_cont(:));
v = [0 n+1 bottom-0.05*(top-bottom)  top+0.05*((top-bottom))];
set(gca,'FontName','Times')
set(gca,'FontSize',14)
title(sprintf('HTTCGP (MSE = %5.2e, Iter=%g, Time=%4.2fs)',  (1/n)*norm(x_HTTCGPCS_cont-f)^2,length(times_HTTCGPCS_cont),times_HTTCGPCS_cont(end)))
axis(v)

scrsz = get(0,'ScreenSize');
% set(7,'Position',[10 scrsz(4)*0.1 0.9*scrsz(3)/2 3*scrsz(4)/4])
subplot(5,1,4)
plot(x_ATTCGPCS_cont(:),'LineWidth',1.1)
top = max(x_ATTCGPCS_cont(:));
bottom = min(x_ATTCGPCS_cont(:));
v = [0 n+1 bottom-0.05*(top-bottom)  top+0.05*((top-bottom))];
set(gca,'FontName','Times')
set(gca,'FontSize',14)
title(sprintf('ATTCGP (MSE = %5.2e,Iter=%g, Time=%4.2fs)',(1/n)*norm(x_ATTCGPCS_cont-f)^2,length(times_ATTCGPCS_cont),times_ATTCGPCS_cont(end)))
axis(v)

scrsz = get(0,'ScreenSize');
% set(7,'Position',[10 scrsz(4)*0.1 0.9*scrsz(3)/2 3*scrsz(4)/4])
subplot(5,1,5)
plot(x_jzyCS_cont(:),'LineWidth',1.1)
top = max(x_jzyCS_cont(:));
bottom = min(x_jzyCS_cont(:));
v = [0 n+1 bottom-0.05*(top-bottom)  top+0.05*((top-bottom))];
set(gca,'FontName','Times')
set(gca,'FontSize',14)
title(sprintf('jzy (MSE = %5.2e,Iter=%g, Time=%4.2fs)',(1/n)*norm(x_jzyCS_cont-f)^2,length(times_jzyCS_cont),times_jzyCS_cont(end)))
axis(v)

% 
% % 
% % 
