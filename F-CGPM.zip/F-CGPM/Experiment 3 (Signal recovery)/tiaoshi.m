clc
clear all
randn('seed',0); % 1 for the experiments in the paper
rand('seed',0); % 1 for the experiments in the paper
R= randn(2,3);
% R = orth(R')'; 
for j = 1:3
    R(:,j) = R(:,j)/norm(R(:,j));%normalize A
end
r1=norm(R(:,3))

% R=randn(2048,8192);
% % orthonormalize rows
% R = orth(R')';
% save('Rmatrix_2048_8192','R');
% load Rmatrix_2048_8192.mat
% A=R;
% a=A(1024,:);
% norm(a')

% for index=1:2
%     n=index*3;
%     m=index*2;
%     x0=rand(n,1)
%     for repeats=1:2
%        R=randn(m,n)
%        hR = @(x) R*x;
%        hRt = @(x) (x'*R)';% R'*x;
%        y=hR(x0)
%     end
% end


% n=-2.5;
% fprintf(1,'Problem: n = %.0f\n',n)