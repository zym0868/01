% Matlab Model by Jianghua Yin (Dec.,2019,Nanning)
% Copyright (C) 2019 Jian Group
% All Rights Reserved
% Permission to use, copy, modify, and distribute this software and
% its documentation for any purpose and without fee is hereby
% granted, provided that the above copyright notice appear in all
% copies and that the copyright notice and this
% permission notice appear in all supporting documentation.  

% This is a demo of HTTCGP method for solving the following constrained
% nonlinear monotone equations
% F(x)=0, x\in C
% where C is a nonempty closed convex set.

% using the algorithm modified three-term conjugate gradient projection method, described in the following paper
%
% -----------------------------------------------------------------------
% Copyright (2019): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 16, 2019
clear all
close all
clc
format long   
format compact
% set parameter
% rand(2)
% setup TXT document
fid_tex=fopen('mytext11.txt','w'); 
% parameter
ns=6;     % number of the test algorithms
np=45;
T=zeros(np,ns);
F=zeros(np,ns);
N=zeros(np,ns);%G=zeros(np,ns);
for index=1:45
    index
    [name,n]=init(index);%Copy_of_init
    progress_r=[];
    for repeats=1:2
        x0 = 2*rand(n,1)-1;
        [T1,NFF1,NI1,G1] = jzy(index,'JZY',x0);
        %[T2,NFF2,NI2,G2] = jzyUI(index,'JZY-UI',x0);
        [T2,NFF2,NI2,G2] = line1(index,'ATTCGP',x0);
        [T3,NFF3,NI3,G3] = SGPYJJ(index,'HTTCG',x0);
        [T4,NFF4,NI4,G4] = line2(index,'PDY',x0);
        
        [T5,NFF5,NI5,G5] = LPJ(index,'MSMCGPM',x0);
        
        [T6,NFF6,NI6,G6] = AHDFPM1(index,'AHDFPM1',x0);
        %[T8,NFF8,NI8,G8] = SGPYHHM1(index,'DYC',x0);
        progress_r=[progress_r;NI1,NFF1,T1,G1,NI2,NFF2,T2,G2,NI3,NFF3,T3,G3,NI4,NFF4,T4,G4,NI5,NFF5,T5,G5,NI6,NFF6,T6,G6];%
    end
    fprintf(fid_tex,'%s %d & %.0f/%.0f/%.3f/%.2e & %.0f/%.0f/%.3f/%.2e & %.0f/%.0f/%.3f/%.2e & %.0f/%.0f/%.3f/%.2e& %.0f/%.0f/%.3f/%.2e& %.0f/%.0f/%.3f/%.2e \n', ... 
                name,n,mean(progress_r));
    TM = mean(progress_r);
    T(index,:) = [TM(3),TM(7),TM(11),TM(15),TM(19),TM(23) ];% ,TM(27)];% 
    F(index,:) = [TM(2),TM(6),TM(10),TM(14),TM(18),TM(22) ];% ,TM(26)];
    N(index,:) = [TM(1),TM(5),TM(9),TM(13),TM(17),TM(21) ];% ,TM(25)]; 
    %G(index,:) = [TM(4),TM(8),TM(12),TM(16),TM(20)],TM(24)],TM(28)]]; 
end
%% �ر��ļ�
fclose(fid_tex);

%% ��ͼ
clf;         
figure(1);
%subplot(2,2,1);
perf(T,'logplot');
%set(gca,'ylim',[0.3,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
legend('F-CGPM','ATTCGP','HTTCGP','PDY','MSMCGPM','AHDFPM1');% ,'ATTCGP');% 
%subplot(2,2,2);
figure(2);
perf(F,'logplot');
% set(gca,'ylim',[0.1,1]);
xlabel('\tau','Interpreter','tex');                   
ylabel('\rho(\tau)','Interpreter','tex');             
legend('F-CGPM','ATTCGP','HTTCGP','PDY','MSMCGPM','AHDFPM1');% ,'ATTCGP');
%subplot(2,2,3);
figure(3);
perf(N,'logplot');
%set(gca,'ylim',[0.5,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
legend('F-CGPM','ATTCGP','HTTCGP','PDY','MSMCGPM','AHDFPM1');% ,'ATTCGP');
