%% Derivative-Free Projection Method
% ================================================================
% MODIFIED: Integrated LPJ (2023) RI-MSMCGPM-N2 algorithm (with inertia)
% Reference: Liu, P.J., Shao, H., Yuan, Z., Wu, X., Zheng, T.
% "A family of three-term conjugate gradient projection methods 
% with a restart procedure and their relaxed-inertial extensions 
% for the constrained nonlinear pseudo-monotone equations with applications"
% Numerical Algorithms, 94, 1055-1083 (2023)
%
% Algorithm 2: Relaxed-inertial MSM conjugate gradient projection methods
% 
% Usage: [Tcpu, NF, Itr, NG] = jzy_LPJ_RI(NO, method, x0)
%   method = 'LPJ' (use LPJ direction)
% ================================================================

function [Tcpu,NF,Itr,NG] = LPJ(NO,method)

format long
Step=0:4;
nextstep=Step(1);
finish=0;
Itr=0;
NF=1;
tic

% ====== LPJ (2023) 参数 (Section 4.1, p.1068) ======
sigma = 0.01;       % line search coefficient
rho_ls = 0.55;      % backtracking factor
t_init = 1;         % initial steplength
mu1 = 0.001;        % lower bound for projection in line search
mu2 = 0.8;          % upper bound for projection in line search
pi = 0.7;           % restart threshold
xi = 0.1;           % restart direction coefficient
alpha_param = 0.2;  % conjugate parameter denominator coefficient
nu_k = 1;           % conjugate parameter coefficient

% MSM parameters
Gamma_MSM = 1;      % initial MSM parameter

% Inertia parameters (RI version)
phi = 0.01;         % inertia coefficient
epsilon_k_series = @(k) 1/((k+1)^2);  % control parameter sequence

% Projection relaxation factor
gamma_k = 1.8;      % relaxation factor

while finish==0
    loop=1;
    while loop==1
        switch nextstep
            case Step(1)
                [nprob,n,x0]=init(NO);
                x2 = x0;
                epsilon=1e-6;
                epsilon1=1e-7;
                
                Fk=feval(nprob,n,x0,1);
                dk=(-1)*Fk;
                
                % LPJ 额外变量初始化
                dk_old = dk;        % d_{k-1}
                Fk_old = Fk;        % G(y_{k-1})
                yk = x0;            % y_k = x_k (初始)
                Fyk = Fk;           % G(y_k)
                x0_history = x0;    % 用于惯性计算
                tau_k = t_init;     % 步长
                
                nextstep=Step(2);
            case Step(2)
                if norm(Fk,2)<=epsilon || Itr>2000  
                    nextstep=Step(5);  
                    break;
                else
                    % LPJ 投影型线搜索
                    t1 = t_init;
                    L1=1;
                    while L1==1
                        z_new = yk + t1 * dk;
                        Fz_new = feval(nprob,n,z_new,1);
                        NF=NF+1;
                        
                        norm_Fz_new = norm(Fz_new);
                        P_mu = min(max(norm_Fz_new, mu1), mu2);
                        
                        if (-Fz_new'*dk < sigma * t1 * P_mu * norm(dk)^2 && t1 > 1e-10)
                            L1=1;
                            t1 = rho_ls * t1;
                        else
                            L1=0;
                        end
                    end
                    
                    zk = yk + t1 * dk;
                    Fzk = feval(nprob,n,zk,1);
                    tau_k = t1;
                end
                nextstep=Step(3);
            case Step(3)
                if norm(Fzk,2)==0
                    xik=0;
                else
                    xik = Fzk' * (yk - zk) / norm(Fzk)^2;
                end
                
                zk1 = yk - gamma_k * xik * Fzk;
                x1 = feval(nprob,n,zk1,2);
                Fk0 = Fk;
                Fk = feval(nprob,n,x1,1);
                NF = NF + 1;
                nextstep=Step(4);
            case Step(4)
                Itr=Itr+1;
                sk = x1 - yk;
                yk_old = yk;
                Fyk = Fk;

                switch method
                    case 'MSMCGPM'
                        pk = Fyk;
                        norm_Fyk = norm(Fyk);
                        norm_pk = norm(pk);
                        Gypk = Fyk' * pk;
                        
                        if abs(Gypk) >= pi * norm_Fyk * norm_pk
                            hk = Fyk - Fk_old;
                            dk_dot_hk = dk_old' * hk;
                            
                            Gyk_dot_Gyk_old = Fyk' * Fk_old;
                            term1 = max(0, nu_k * (norm_Fyk / norm(Fk_old)) * Gyk_dot_Gyk_old);
                            numerator_beta = norm_Fyk^2 - max(0, term1);
                            
                            denominator_beta = alpha_param * (norm(dk_old)^2 + norm_Fyk^2) ...
                                               + max(norm(Fk_old)^2, dk_dot_hk);
                            
                            if denominator_beta == 0
                                beta_k = 0;
                            else
                                beta_k = numerator_beta / denominator_beta;
                            end
                            
                            zeta_k = 1 + tau_k - tau_k^2;
                            
                            numerator_eta = (1 - zeta_k / Gamma_MSM) * norm_Fyk^2 ...
                                            - beta_k * (Fyk' * dk_old);
                            
                            if abs(Gypk) < 1e-12
                                eta_k = 0;
                            else
                                eta_k = numerator_eta / Gypk;
                            end
                            
                            dk = -Fyk + beta_k * dk_old + eta_k * pk;
                            
                        else
                            if norm_pk == 0
                                dk = -Fyk;
                            else
                                dk = -Fyk + xi * (Fyk' * pk) / (norm_pk^2) * pk;
                            end
                        end
                        
                        dk_old = dk;
                        Fk_old = Fyk;
                        
                    case 'JZY'
                       seg=0.01;
                        mu=0.4;
                         rho1 = 15;
                         rho2 = 50;
                          lower_bound = -rho1 * norm(Fk) / norm(dk);
                          upper_bound =  rho2 * norm(Fk) / norm(dk);
                          betak0 = (norm(Fk)^2-Fk'*Fk0) / (norm(Fk0)^2);
                          betak1 = max(lower_bound, min(betak0, upper_bound));
                        if abs(betak1 * (Fk'*dk)) < mu * norm(Fk)^2
                      dk = -Fk + betak1 * dk;
                        else
                      pk = dk;
                     dk = -Fk + seg * (Fk'*pk) / (norm(pk)^2) * pk;
                         end
                end
                
                if norm(dk)<epsilon1
                    nextstep=Step(5);
                    break;
                end
                
                % MSM 参数 Gamma_{k+1}^{MSM} 更新
                hk = Fyk - Fk_old;
                norm_hk = norm(hk);
                zeta_k = 1 + tau_k - tau_k^2;
                
                denom_Gamma = tau_k * zeta_k * (1 / Gamma_MSM) * (hk' * Fk_old);
                
                if abs(denom_Gamma) < 1e-12 || denom_Gamma == 0
                    Gamma_MSM_new = 1;
                else
                    Gamma_MSM_new = -norm_hk^2 / denom_Gamma;
                end
                
                if Gamma_MSM_new <= 0
                    Gamma_MSM_new = 1;
                end
                Gamma_MSM = Gamma_MSM_new;
                
                % LPJ 惯性更新 (RI 版本)
                x2 = x0;
                x0 = x1;
                
                norm_x_diff = norm(x0 - x2);
                if norm_x_diff > 0
                    phi_k = min(phi, epsilon_k_series(Itr) / norm_x_diff);
                else
                    phi_k = phi;
                end
                % 惯性外推: y_{k+1} = x_{k+1} + phi_k * (x_{k+1} - x_k)
                yk = x0 + phi_k * (x0 - x2);
                
                Fyk = feval(nprob,n,yk,1);
                NF = NF + 1;
                Fk = Fyk;
                
                nextstep=Step(2);
            case Step(5)
                loop=0;
        end
    end
    if Itr>=2001
      Tcpu=NaN;
      NF=NaN;
      Itr=NaN;
      NG=NaN;
    else
      Tcpu=toc; 
      NG=norm(Fk);
    end
    finish=1;
end