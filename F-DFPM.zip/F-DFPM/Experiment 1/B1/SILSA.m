function [Tcpu,NF,Itr,NG] = SILSA(NO,method,x0)
% Derivative-Free Projection Method
% method = 'SILSA' 时执行 Kimiaei 等人的 SILSA 算法
% 其他 method 保持原算法逻辑

format long
Step = 0:4;
nextstep = Step(1);
finish = 0;
Itr = 0;
NF = 1;
tic

while finish == 0
    loop = 1;
    while loop == 1
        switch nextstep

            %% ============ Step 0: 初始化 ============
            case Step(1)
                [nprob, n] = init(NO);

                if strcmpi(method, 'SILSA')
                    % -------- SILSA 初始化（论文第5节默认值） --------
                    epsilon   = 1e-6;
                    epsilon1  = 1e-7;
                    sigma     = 0.01;
                    c         = 0.5;
                    r         = 0.5;
                    delta_max = 0.5;
                    delta_min = 0;
                    omega_d   = 2;
                    e_max     = 1e-4;
                    nu        = 1e-20;
                    m         = 10;

                    % 子空间矩阵与残差范数向量
                    X      = repmat(x0, 1, m);
                    Fw     = feval(nprob, n, x0, 1);
                    NF     = NF + 1;
                    NF_vec = repmat(norm(Fw), 1, m);

                    % 惯性权重 lambda_j（论文公式: mu = 4 + floor(3*ln(n))）
                    mu_param = 4 + floor(3 * log(n));
                    lambda0  = zeros(1, m-1);
                    for i = 1:m-1
                        lambda0(i) = log(mu_param + 0.5) - log(i);
                    end
                    lambda = lambda0 / sum(lambda0);

                    % 初始子空间惯性点 w0 = x0
                    w  = x0;

                    % 初始方向 d0 = -c * F(w0)（论文公式20）
                    dk = -c * Fw;

                    % 初始步长控制
                    delta = delta_max;

                else
                    % -------- 原算法初始化 --------
                    epsilon   = 1e-6;
                    epsilon1  = 1e-7;
                    alpha     = 0.001;
                    gammak    = 1;
                    sigma     = 0.01;
                    gamma     = 0.55;
                    rho       = 0.55;
                    l         = 2;
                    x2 = x0;
                    alphak0 = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                    x0 = x0 + alphak0*(x0-x2);
                    Fk = feval(nprob, n, x0, 1);
                    dk = -Fk;
                end
                nextstep = Step(2);

            %% ============ Step 1: 线搜索 ============
            case Step(2)
                if strcmpi(method, 'SILSA')
                    % -------- SILSA 线搜索（论文公式23-25） --------
                    if norm(Fw,2) <= epsilon || Itr > 2000
                        nextstep = Step(5);
                        break;
                    end
                    t1 = delta;
                    L1 = 1;
                    while L1 == 1
                        z_new  = w + t1 * dk;
                        Fz_new = feval(nprob, n, z_new, 1);
                        NF = NF + 1;
                        if -Fz_new' * dk < sigma * t1 * norm(Fz_new,2) * norm(dk,2)^2 && t1 > 1e-15
                            L1 = 1;
                            t1 = t1 * r;
                        else
                            L1 = 0;
                        end
                    end
                    zk  = z_new;
                    Fzk = Fz_new;

                else
                    % -------- 原算法线搜索 --------
                    if norm(Fk,2) <= epsilon || Itr > 2000
                        nextstep = Step(5);
                        break;
                    end
                    t1 = gamma;
                    L1 = 1;
                    while L1 == 1
                        z_new  = x0 + t1 * dk;
                        Fz_new = feval(nprob, n, z_new, 1);
                        z      = x0;
                        Fz     = feval(nprob, n, z, 1);
                        NF = NF + 1;
                        if (-Fz_new' * dk < sigma * t1 * norm(Fz_new,2) * (norm(Fz,2))^(1-l) * norm(dk,2)^l && t1 > 1e-10)
                            L1 = 1;
                            t1 = t1 * rho;
                        else
                            L1 = 0;
                        end
                    end
                    zk  = x0 + t1 * dk;
                    Fzk = feval(nprob, n, zk, 1);
                end
                nextstep = Step(3);

            %% ============ Step 2: 投影 ============
            case Step(3)
                if strcmpi(method, 'SILSA')
                    % -------- SILSA 投影（论文公式30，系数为1） --------
                 xik    = Fzk' * (w - zk) / norm(Fzk)^2;   % 超平面系数
                 x_temp = w - xik * Fzk;                    % 第一步：超平面投影
                 x1     = feval(nprob, n, x_temp, 2);       % 第二步：投影回 C
                 Fk0    = Fw;
                 Fk     = feval(nprob, n, x1, 1);
                 NF = NF + 1;
                else
                    % -------- 原算法投影（系数1.86） --------
                    xik = Fzk' * (x0 - zk) / norm(Fzk)^2;
                    zk1 = x0 - 1.86 * xik * Fzk;
                    x1  = feval(nprob, n, zk1, 2);
                    Fk0 = Fk;
                    Fk  = feval(nprob, n, x1, 1);
                    NF  = NF + 1;
                end
                nextstep = Step(4);

            %% ============ Step 3: 更新 ============
            case Step(4)
                Itr = Itr + 1;

                % 全代码唯一的 switch method
                switch method

                    case 'SILSA'
                        % ========== SILSA 更新 ==========
                        % 1) 子空间更新：用 x1 替换残差最大的列（LP点）
                        Fx1 = Fk;
                        [~, idx]    = max(NF_vec);
                        X(:, idx)   = x1;
                        NF_vec(idx) = norm(Fx1);

                        % 2) 子空间惯性点（论文公式16-17）
                        sum_vec = zeros(n,1);
                        for j = 1:m-1
                            sum_vec = sum_vec + lambda(j) * (X(:, j+1) - X(:, j));
                        end
                        norm_sum = norm(sum_vec);
                        if norm_sum > 0
                            e_next = min(e_max, Itr^(-2) * norm_sum^(-2));
                        else
                            e_next = e_max;
                        end
                        w_new  = x1 + e_next * sum_vec;
                        Fw_new = feval(nprob, n, w_new, 1);
                        NF = NF + 1;

                        % 3) 停止检查
                        if norm(Fw_new) < epsilon
                            x0 = w_new; Fk = Fw_new;
                            nextstep = Step(5); break;
                        end
                        if delta <= delta_min
                            x0 = w_new; Fk = Fw_new;
                            nextstep = Step(5); break;
                        end

                        % 4) 无导数谱方向（论文公式20-22）
                        y_k   = Fw_new - Fk0;
                        beta  = - (Fw_new' * y_k) / (Fk0' * dk);
                        theta = c + beta * (Fw_new' * dk) / norm(Fw_new)^2;
                        dk    = -theta * Fw_new + beta * dk;

                        % 5) delta 更新（论文公式27-29）
                        fz = 0.5 * norm(Fzk)^2;
                        fw = 0.5 * norm(Fk0)^2;
                        if fz < fw - nu * delta
                            delta = min(omega_d * delta, delta_max);
                        else
                            delta = delta / omega_d;
                        end

                        % 6) 变量推进
                        w  = w_new;
                        Fw = Fw_new;
                        x0 = w;     % 统一输出变量
                        Fk = Fw;

                    case 'JZY'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        seg = 0.01;
                        mu  = 0.4;
                        rho1 = 15;
                        rho2 = 50;
                        lower_bound = -rho1 * norm(Fk) / norm(dk);
                        upper_bound =  rho2 * norm(Fk) / norm(dk);
                        betak0 = (norm(Fk)^2 - Fk'*Fk0) / (norm(Fk0)^2);
                        betak1 = max(lower_bound, min(betak0, upper_bound));
                        if abs(betak1 * (Fk'*dk)) < mu * norm(Fk)^2
                            dk = -Fk + betak1 * dk;
                        else
                            pk = dk;
                            dk = -Fk + seg * (Fk'*pk) / (norm(pk)^2) * pk;
                        end
                        % 原惯性加速
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'HZF3'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        vv = 1.8;
                        numerator = abs(Fk'*yk);
                        denominator = max(abs(Fk'*dk), vv*norm(dk)*norm(yk));
                        betak = numerator/denominator;
                        numer = norm(Fk)^2*(1-corr*gammak^(-1))-betak*(Fk'*dk);
                        denominatorp = Fk'*dk;
                        thetak = numer/denominatorp;
                        ll = 0.5; rr = 0.8; kkk = 0.01;
                        if -ll*norm(Fk)^2 <= betak*(Fk'*dk) && betak*(Fk'*dk) >= rr*norm(Fk)^2
                            dk = -Fk + betak*dk + thetak*Fk;
                        else
                            dk = -Fk + kkk*(Fk'*yk)*yk/norm(yk)^2;
                        end
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'HTTCGN'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        lambdak = 1 + max(0, -yk'*sk/(norm(Fk)*norm(sk)^2));
                        yk1 = yk + lambdak*norm(Fk)*sk;
                        tk  = min(0.3, max(0, 1 - yk'*sk/norm(yk)^2));
                        mu  = 0.2;
                        fenmu = max(norm(Fk0)^2, max(mu*norm(dk)*norm(yk1), dk'*yk1));
                        thetak = tk*Fk'*dk/fenmu;
                        betak  = Fk'*yk1/fenmu - norm(yk1)^2*Fk'*dk/fenmu^2;
                        dk = -Fk + betak*dk + thetak*yk1;
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'PDY'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        tk = 1 + max(0, -dk'*yk/norm(dk)^2);
                        wk = yk + tk*dk;
                        betak = norm(Fk)^2/(dk'*wk);
                        cc = 1;
                        thetak = cc - Fk'*dk/(dk'*wk);
                        dk = -thetak*Fk + betak*dk;
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'TPRP'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        mu = 0.01;
                        dk = -Fk + (Fk'*yk*dk - Fk'*dk*yk)/max(mu*norm(dk)*norm(yk), norm(Fk0)^2);
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'IDFPI'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        beltk = 0.01*norm(Fk)/norm(dk);
                        dk = -(1 + beltk*Fk'*dk/(norm(Fk)^2))*Fk + beltk*dk;
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'WYL'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        betak = Fk'*(Fk - norm(Fk)/norm(Fk0)*Fk0)/norm(Fk0)^2;
                        dk = -Fk + betak*dk;
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'PRP+'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        betak = max(0, Fk'*(Fk - Fk0)/norm(Fk0)^2);
                        dk = -Fk + betak*dk;
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;

                    case 'HTTCG'
                        sk = x1 - x0;
                        yk = Fk - Fk0;
                        tk = min(0.3, max(0, 1 - yk'*sk/norm(yk)^2));
                        mu = 0.2;
                        fenmu = max(norm(Fk0)^2, max(mu*norm(dk)*norm(yk), dk'*yk));
                        thetak = tk*Fk'*dk/fenmu;
                        betak  = Fk'*yk/fenmu - norm(yk)^2*Fk'*dk/fenmu^2;
                        dk = -Fk + betak*dk + thetak*yk;
                        x2 = x0; x0 = x1;
                        alphak = min(alpha, 1/((Itr^2)*norm(x0-x2,2)));
                        x0 = x0 + alphak*(x0 - x2);
                        Fk = feval(nprob, n, x0, 1); NF = NF + 1;
                end

                if norm(dk) < epsilon1
                    nextstep = Step(5);
                    break;
                end
                nextstep = Step(2);

            %% ============ Step 4: 收尾 ============
            case Step(5)
                loop = 0;
        end
    end

    if Itr >= 2001
        Tcpu = NaN; NF = NaN; Itr = NaN; NG = NaN;
    else
        Tcpu = toc;
        NG = norm(Fk);
    end
    finish = 1;
end
end