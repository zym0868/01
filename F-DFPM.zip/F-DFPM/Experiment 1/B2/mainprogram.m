% Matlab Model by Jianghua Yin (Dec.,2019,Yulin)
% Copyright (C) 2019 Jian Group
% All Rights Reserved
% Permission to use, copy, modify, and distribute this software and
% its documentation for any purpose and without fee is hereby
% granted, provided that the above copyright notice appear in all
% copies and that the copyright notice and this
% permission notice appear in all supporting documentation.  

% This is a demo of JHYTTCGPM(which respond to the method PRPTTCGPM1-4) method for solving the following constrained
% nonlinear monotone equations
% F(x)=0, x\in C
% where C is a nonempty closed convex set.

% using the algorithm modified three-term conjugate gradient projection method, described in the following paper
%
%  A conjugate gradient projection method with restart procedure for solving constraint equations and image restorations
% -----------------------------------------------------------------------
% Copyright (2019): Jianghua Yin
% ----------------------------------------------------------------------
%
% The first version of this code by Jianghua Yin, Dec., 16, 2019
%clear all 
clc;
format long
format compact
%% ����latex�����ļ�
fid_tex=fopen('mytext.txt','w'); 
%% ��ʼ������
%np=168;    %���⼯�ĸ���
np=189;    %���⼯�ĸ���
%168+21 = 189
ns=6;     %�㷨�ĸ���
%Tot1 = [];   
T=zeros(np,ns);F=zeros(np,ns);N=zeros(np,ns); %G=zeros(np,ns);
%

%% ����
for i=1:np
  % 1:np
i                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
[name,n,a]=init(i);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
% name=getname(nprob);
%[T1,NFF1,NI1,G1] = line1(i,'ATTCGP');       % acceleration
%[T2,NFF2,NI2,G2] = SGPYHHM1(i,'JZY1');
% Liu J, Feng Y. (2018) PDY, Numerical Algorithms
%[T2,NFF2,NI2,G2] = SGPYJJ(i,'HTTCG');      % Sun M., Liu J., (2016) HCGP, Calcolo  

[T1,NFF1,NI1,G1] = AHDFPM1(i,'AHDFPM1');
[T2,NFF2,NI2,G2] = SILSA(i,'SILSA');  
[T3,NFF3,NI3,G3] = SGPYJJ(i,'HTTCG');
[T4,NFF4,NI4,G4] = line2(i,'PDY');
[T5,NFF5,NI5,G5] = LPJ(i,'MSMCGPM');
[T6,NFF6,NI6,G6] = F_DFPM(i,'F_DFPM');

T(i,:) = [T1,T2,T3,T4,T5,T6];
F(i,:) = [NFF1,NFF2,NFF3,NFF4,NFF5,NFF6];
N(i,:) = [NI1,NI2,NI3,NI4,NI5,NI6];
%T(i,:) = [T1,T2,T3,T4];
%F(i,:) = [NFF1,NFF2,NFF3,NFF4];
%N(i,:) = [NI1,NI2,NI3,NI4];
%G = [G3,G4,G5]; %,G5];
b=n/10000;
%% ���뵽 latex 
fprintf(fid_tex,'%s $x_{%d}(%d)$ &%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e\\\n',...
                name,b,b,NI1,NFF1,T1,G1,NI2,NFF2,T2,G2,NI3,NFF3,T3,G3,NI4,NFF4,T4,G4,NI5,NFF5,T5,G5,NI6,NFF6,T6,G6);
%fprintf(fid_tex,'%s $x_{%d}(%d)$ &%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&%d/%d/%.3f/%.2e&\\\n',...
%                name,b,b,NI1,NFF1,T1,G1,NI2,NFF2,T2,G2,NI3,NFF3,T3,G3,NI4,NFF4,T4,G4);            
end
%sum_tol1 = sum(Tot1)
%% �ر��ļ�
fclose(fid_tex);


%% ---- ��ʵ�����ܣ�ʧ�ܴ��� / ��ֵ / ��λ�� ----
maxit = 2000;
methods = {'AHDFPM1','SILSA','HTTCGP','PDY','MSMCGPM','F-DFPM'};
ns = size(N,2);

fid_sum = fopen('summary.txt','w');
fprintf(fid_sum,'%-10s | %5s | %8s %8s | %8s %8s | %9s %9s\n', ...
        'Method','Fail','meanItr','medItr','meanNF','medNF','meanTime','medTime');
fprintf('%-10s | %5s | %8s %8s | %8s %8s | %9s %9s\n', ...
        'Method','Fail','meanItr','medItr','meanNF','medNF','meanTime','medTime');

for j = 1:ns
    bad = (N(:,j) >= maxit) | isnan(N(:,j)) | isnan(F(:,j)) | isnan(T(:,j));
    fail = sum(bad);

    Itr_ok = N(~bad,j);
    NF_ok  = F(~bad,j);
    Time_ok= T(~bad,j);

    line = sprintf('%-10s | %5d | %8.1f %8.1f | %8.1f %8.1f | %9.3f %9.3f\n', ...
        methods{j}, fail, ...
        mean(Itr_ok), median(Itr_ok), ...
        mean(NF_ok),  median(NF_ok), ...
        mean(Time_ok),median(Time_ok));
    fprintf(fid_sum,'%s',line);
    fprintf('%s',line);
end
fclose(fid_sum);

%% ��ͼ
clf;   %clfɾ����ǰͼ�δ����С�
       %%���δ������(�����ǵ�HandleVisibility����Ϊon)��ͼ�ζ���
figure(1);
%subplot(2,2,1);
perf(T,'logplot');
%title('ʱ������');
%set(gca,'ylim',[0.3,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
%legend('F-DFCGPM-0.1','F-DFCGPM-0.9','F-DFCGPM-1','F-DFCGPM-1.5');
legend('AHDFPM1','SILSA','HTTCGP','PDY','MSMCGPM','F-DFPM');
%subplot(2,2,2);
figure(2);
perf(F,'logplot');
%title('Ŀ�꺯����������');
% set(gca,'ylim',[0.1,1]);
xlabel('\tau','Interpreter','tex');                 
ylabel('\rho(\tau)','Interpreter','tex');  
%legend('F-DFCGPM-0.1','F-DFCGPM-0.9','F-DFCGPM-1','F-DFCGPM-1.5');
legend('AHDFPM1','SILSA','HTTCGP','PDY','MSMCGPM','F-DFPM');
%subplot(2,2,3);
figure(3);
perf(N,'logplot');
%title('������������');
%set(gca,'ylim',[0.5,1]);
xlabel('\tau','Interpreter','tex');
ylabel('\rho(\tau)','Interpreter','tex');
%legend('F-DFCGPM-0.1','F-DFCGPM-0.9','F-DFCGPM-1','F-DFCGPM-1.5');
legend('AHDFPM1','SILSA','HTTCGP','PDY','MSMCGPM','F-DFPM');